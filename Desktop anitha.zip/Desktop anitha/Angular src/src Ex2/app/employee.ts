export class Employee {
    id: number;
    name: string;
    email: string;
    phone: number;
  }
  