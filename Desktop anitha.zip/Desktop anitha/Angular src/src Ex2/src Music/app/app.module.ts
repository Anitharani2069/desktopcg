import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchMusicComponent } from './music/search-music.component';
import { HomeComponent } from './music/home.component';
import { ShowAlbumsComponent } from './music/show-albums.component';
import { MusicService } from './music/music.service';
import { HttpClientModule } from '@angular/common/http';
import { AddMusicComponent } from './music/add-music.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchMusicComponent,
    HomeComponent,
    ShowAlbumsComponent,
    AddMusicComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule
  ],
  providers: [MusicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
