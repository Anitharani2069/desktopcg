import { Injectable } from '@angular/core';
import { Music } from './music';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MusicService {
  musics:Music[];
  constructor(private http:HttpClient) { 
    this.populateMusic().subscribe(data=>this.musics=data,error=>console.log(error));
  }
  populateMusic():Observable<Music[]>{
    return this.http.get<Music[]>("../../assets/musics.json");
  }
  getMusic():Music[]{
    return this.musics;
  }
  addMusic(music:Music)
  {
    this.musics.push(music);
  }
  deleteMusic(id){
    this.musics=this.musics.filter(music=>music.id!=id);
  }
}
