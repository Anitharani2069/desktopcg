import { Component, OnInit } from '@angular/core';
import { ProductDetails } from '../productdetails';
import { ProductdetailsService } from '../productdetails.service';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  empList:ProductDetails[];
  constructor(private service:ProductdetailsService) { }

  ngOnInit() {
    this.getAllDetails();
  }

  getAllDetails()
  {
    this.service.getAllDetails().subscribe(data=>this.empList=data);
  }
}
