export interface ProductDetails{
    ProductId:string;
    Category:string;
    MainCategory:string;
    TaxTarifCode:number;
    SupplierName:string

    
    
    
    }