import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { ProductDetails } from './productdetails';
@Injectable({
  providedIn: 'root'
})
export class ProductdetailsService {

  
  url:string='/assets/productBrands.json';

  constructor(private http:HttpClient) {}
  getAllDetails():Observable<ProductDetails[]>
  {
    return this.http.get<ProductDetails[]>(this.url);
  }
}
