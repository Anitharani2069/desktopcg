import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import {FormsModule} from '@angular/forms';
import { ProductdetailsService } from './productdetails.service';
const routes:Routes=[

  {path:'about',component:AboutComponent},
  {path:'product',component:ProductdetailsComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    ProductdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,

    RouterModule.forRoot(routes)
  ],
  providers: [ProductdetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
