import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { EmployeeService} from './employee.service';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
const routes: Routes = [

  {path: 'home', component: ListAllEmployeesComponent},
  {path: 'login', component: AddEmployeeComponent},
 ];
@NgModule({
  declarations: [
    AppComponent,
    ListAllEmployeesComponent,
    AddEmployeeComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
