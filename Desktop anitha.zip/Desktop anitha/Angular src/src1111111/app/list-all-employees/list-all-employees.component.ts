import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  empList: Employee[];
  constructor(private service:EmployeeService) { 
   
  }
  
  ngOnInit() {

    this.getAllEmployees();
    }
  
    getAllEmployees() {
    this.service.getAllEmployees().subscribe(data => this.empList = data);
    }
    deleteemployeeInfo(i)
      {
        this.empList.splice(i,1);
       }

       updateEmployee(updateform)
   {
  let count=0;
  for(let i=0;i<this.empList.length; i++)
   {
  if(this.empList[i].eid==updateform.value.eid)
   {
  this.empList[i]=updateform.value;
  count=1;
   }
   }
  if(count==0)
   {
  alert('updation failed');
   }
   }

  }
