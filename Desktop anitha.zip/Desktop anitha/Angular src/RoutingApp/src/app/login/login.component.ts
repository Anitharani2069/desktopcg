import { Component, OnInit } from '@angular/core';
import { Subscriber } from '../../../node_modules/rxjs';
import { PARAMETERS } from '../../../node_modules/@angular/core/src/util/decorators';
import { ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
uname:string;
  constructor(private root:ActivatedRoute) { 
    root.params.subscribe(params => this.uname=params['uname'])
  }

  ngOnInit() {
  }

}
