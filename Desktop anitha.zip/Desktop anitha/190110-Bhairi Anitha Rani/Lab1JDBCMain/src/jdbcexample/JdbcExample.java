package jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcExample {
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		PreparedStatement pst;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			System.out.println("driver loaded");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			Statement stmt = connection.createStatement();
			Scanner sc=new Scanner(System.in);
			//System.out.println("1. Create table");
			for(;;)
			{
			System.out.println("1. display author name");
			System.out.println("2. insert value in isbn and author table");
			System.out.println("3. update respect to author name");
			System.out.println("4. display records");
			System.out.println("5. Exit");
			System.out.println("Enter your choice:");
			int choice=sc.nextInt();
			switch(choice)
			{
			
			case 1:	ResultSet resultSet = stmt.executeQuery("select title from isbnt where isbn =(select bookid from bookauthors where bookid=2)");
					while(resultSet.next())
					{
					    System.out.println(resultSet.getString(1));    
					}
					break;
			
			case 2:
				System.out.println("Enter title");
				String title=scanner.next();
				System.out.println("Enter price:");
				int price=scanner.nextInt();
				PreparedStatement pst1=connection.prepareStatement("insert into isbnt values(isbnt_sequence.nextval,?,?)");
				pst1.setString(1,title);
				pst1.setInt(2,price);
				pst1.executeUpdate();
				System.out.println("Enter name:");
				String name=scanner.next();
				PreparedStatement pst2=connection.prepareStatement("insert into authort values(id_sequences.nextval,?)");
				pst2.setString(1, name);
				pst2.executeUpdate();
				System.out.println("Record inserted");
				break;
			
			case 3:
				System.out.println("Enter author name:");
				String name1=scanner.next();
				pst=connection.prepareStatement("update isbnt set price=111113 where isbn=(select id from authort where name=?)");
				pst.setString(1,name1);
				pst.executeUpdate();
				System.out.println("record updated successfully");
				break;
			case 4:
				ResultSet resultSet2=stmt.executeQuery("select isbn,title,price from isbnt");
				while(resultSet2.next())
				{
					System.out.println(resultSet2.getInt("isbn"));
					System.out.println(resultSet2.getString("title"));
					System.out.println(resultSet2.getInt("price"));

				}
				
				ResultSet resultSet3=stmt.executeQuery("select id,name from authort");
				while(resultSet3.next())
				{
					System.out.println(resultSet3.getInt("id"));
					System.out.println(resultSet3.getString("name"));
					
				}
				
				break;
			case 5:
				System.exit(0);
				
				}
			System.out.println("do you want to continue");
			String str=sc.next();
			if(str.equals("y")||str.equals("Y"))
			{
				continue;
			}
			else
			{
				break;
			}
		
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
