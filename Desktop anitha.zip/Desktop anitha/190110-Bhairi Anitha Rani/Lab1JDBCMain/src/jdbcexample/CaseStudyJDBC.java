package jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CaseStudyJDBC {

	public static void main(String[] args) throws SQLException {
		Scanner scanner=new Scanner(System.in);
		PreparedStatement pst;
		try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		System.out.println("driver loaded");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
		Statement stmt = connection.createStatement();
		System.out.println("");
		
		Scanner sc=new Scanner(System.in);
		//System.out.println("1. Create table");
		for(;;)
		{
		System.out.println("1. sum of salary of employees");
		System.out.println("2. count the employees");
		System.out.println("3. months and days from hiredate of employee");
		System.out.println("4. department without employees.");
		System.out.println("5. employees without department.");
		System.out.println("6. Employee hiredate and day");
		System.out.println("7. Exit");

		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:ResultSet resultSet=stmt.executeQuery("select sum(salary) from employeetable");
		//	System.out.println(resultSet);
			while(resultSet.next())
			{
			    System.out.println("Sum of salary of all employees is:"+resultSet.getInt(1));    

			}
			break;
		
		case 2:ResultSet resultSet1=stmt.executeQuery("select count(e.employeeid),d.departmentname from department d inner join employeetable e on d.DEPARTMENTID=e.DEPARTMENTID group by d.departmentname");
			while(resultSet1.next())
			{
			    System.out.println("Count of employee:"+resultSet1.getInt(1));
			    System.out.println("Department name:"+resultSet1.getString(2));    

	
			}
			break;
		case 3:
			ResultSet resultSet2=stmt.executeQuery("select firstname, round((months_between(sysdate,hiredate))) as months,to_date(sysdate)-to_date(hiredate) as days from employeetable1");
			while(resultSet2.next())
			{
			    System.out.println("Name of the employee:"+resultSet2.getString(1));
			    System.out.println("Months from hiredate:"+resultSet2.getString(2));   
			    System.out.println("Days from hiredate:"+resultSet2.getString(3));   
			}
			break;
				
		case 4:
			ResultSet resultSet3=stmt.executeQuery("select departmentname from department d left outer join employeetable1 e on d.DEPARTMENTID=e.DEPARTMENTID group by d.departmentid,departmentname having count(e.employeeid)=0");
			while(resultSet3.next())
			{
			 System.out.println("department name:"+resultSet3.getString(1));
			}
			break;
		case 5:
			ResultSet resultSet4=stmt.executeQuery("select  e.firstname from department d left outer join employeetable1 e on d.DEPARTMENTID=e.DEPARTMENTID group by d.departmentid,e.firstname having count(e.employeeid)=0");

			while(resultSet4.next())
			{
				 System.out.println("Employee name:"+resultSet4.getString(1));
				   // System.out.println("count:"+resultSet4.getInt(2));   
			}
			break;
			
		case 6:
			ResultSet resultSet5=stmt.executeQuery("select firstname,hiredate,to_char(hiredate,'day') as day from EMPLOYEETABLE1");
			while(resultSet5.next())
			{
				 System.out.println("Employee name:"+resultSet5.getString(1));
				 System.out.println("Hiredate:"+resultSet5.getString(2));
				 System.out.println("day :"+resultSet5.getString(3));
			}
			break;
		case 7:
			System.exit(0);
		}
		System.out.println("do you want to continue");
		String str=sc.next();
		if(str.equals("y")||str.equals("Y"))
		{
			continue;
		}
		else
		{
			break;
		}
		}
		}
		
		
		catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}

	}
}

