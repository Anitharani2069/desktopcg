package jdbcexample;


import java.sql.*;
import java.util.Scanner;

public class AuthorInformation {
		public static void main(String[] args) throws SQLException  {
		Scanner scanner=new Scanner(System.in);
		PreparedStatement pst;
		try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		System.out.println("driver loaded");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
		System.out.println("");
		
		Scanner sc=new Scanner(System.in);
		//System.out.println("1. Create table");
		for(;;)
		{
		System.out.println("1. insert table");
		System.out.println("2. update table");
		System.out.println("3. delete table");
		System.out.println("4. Exit");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("enter id");
			int id=scanner.nextInt();
			System.out.println("enter first name");
			String name=scanner.next();
			System.out.println("enter middle name");
			String name1=scanner.next();
			System.out.println("enter last name");
			String name2=scanner.next();
			System.out.println("enter mobile number");
			int number=scanner.nextInt();
			 pst= connection.prepareStatement("insert into Author values(?,?,?,?,?)");
			
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, name1);
			pst.setString(4, name2);
			pst.setInt(5, number);
			
			pst.executeUpdate();
			System.out.println("records inserted");
			break;
			
		case 2: 
			 pst= connection.prepareStatement("update Author set firstname=?,middlename=?,lastname=?,mobileno=?where authorid=?");
					pst.setString(1,"jyoti");	
					pst.setString(2,"R");
					pst.setString(3,"varma");
					pst.setInt(4,123);
					pst.setInt(5,4);
					pst.executeUpdate();
					System.out.println("record updated successfully");
					break;

		case 3: 
			int authorId=scanner.nextInt();
			pst=connection.prepareStatement("delete from Author where authorid=?");
			pst.setInt(1, authorId);
			pst.executeUpdate();
			System.out.println("record deleted");
			break;
		case 4:
			System.exit(0);
		}
		System.out.println("do you want to continue");
		String str=scanner.next();
			if(str.equals("y")||str.equals("Y"))
			{
				continue;
			}
			else
			{
				break;
			}
		}

	} catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	}

}
}
