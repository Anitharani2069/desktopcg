package lab8Training;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
public class Excercise3 {
    public static void main(String args[]) throws IOException
    {
        
        FileReader fileread=new FileReader("source.txt");
        @SuppressWarnings("resource")
        BufferedReader buffread=new BufferedReader(fileread);
        int charCount=0;
        int wordCount=0;
        int lineCount=0;
        String string;
        while((string=buffread.readLine())!=null)
        {
            lineCount++;
            String str1[]=string.split(" ");
            wordCount=wordCount+str1.length;
            for(String str3:str1) 
            {
                charCount=charCount+str3.length();
            }
            
        }
        System.out.println("Line count:"+lineCount);
        System.out.println("Word count:"+wordCount);
        System.out.println("Character count:"+charCount);

            
    }
}