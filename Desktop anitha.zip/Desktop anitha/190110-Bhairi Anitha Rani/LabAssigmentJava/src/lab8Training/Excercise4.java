package lab8Training;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class Excercise4 {
	 public static void main(String[] args) throws IOException
	    {
	        Scanner scan=new Scanner(System.in);
	        String string=scan.next();
	        String filetype="undefined";
	        File file=new File(string);
	        if(file.exists())
	        {
	            System.out.println("file exists");
	        
	        if(file.canRead())
	        {
	            System.out.println("File is readable");
	        }
	        if(file.canWrite())
	        {
	            System.out.println("File is writable");
	        }
	        
	        filetype=Files.probeContentType(file.toPath());
	        System.out.println(file.length());
	        System.out.println(filetype);
	        }
	else
	    {
	        System.out.println("File not found");
	    }
	}
	}
	 


