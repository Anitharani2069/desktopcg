package lab8Training;

import java.util.Arrays;
import java.util.Scanner;

public class Excercise5 {
    static boolean order(String alph)
    {
        boolean flag=true;
        int number=alph.length();
        char character[]=new char[number];
        for(int i=0;i<number;i++)
            character[i]=alph.charAt(i);
            Arrays.sort(character);
for(int i=0;i<number;i++)
{
if(character[i]!=alph.charAt(i)){
    flag=false;
      break;
}
}
System.out.println("String is positive:"+flag);
return flag;
    }
public static void main(String args[])
{
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the String");
    String output=scan.next();
    order(output);
    scan.close();
}
}
 