package lab8Training;

public class Excercise7 {
	public static boolean validate(String name) {
        String string = name.substring(0,name.length()-4);
        if(name.substring(8,name.length()).equals("_job") && string.length()==8) {
            return true;
        }
        else
            return false;
    }
public static void main(String args[]) {
    System.out.println(validate("anithacg_job"));
}
}
 




