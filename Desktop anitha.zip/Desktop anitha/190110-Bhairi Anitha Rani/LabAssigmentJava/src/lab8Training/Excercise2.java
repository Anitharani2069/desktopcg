package lab8Training;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;

public class Excercise2 {
	public static void main(String[] arg)throws IOException
	{
		BufferedReader buffRead=new BufferedReader(new FileReader("source.txt"));
		int count=1;
		String string=buffRead.readLine();
		while(string!=null)
		{
			System.out.println(count+"."+string);
			string=buffRead.readLine();
			count++;
		}
		buffRead.close();
	}

}
