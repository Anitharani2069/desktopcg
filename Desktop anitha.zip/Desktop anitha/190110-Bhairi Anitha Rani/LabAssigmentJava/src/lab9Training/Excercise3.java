package lab9Training;

import java.util.*;

import java.util.Scanner;
public class Excercise3 {
	public void getSquares(int arr[])
	{
		int length1=arr.length;
		HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>();
		for(int i=0;i<length1;i++) {
			hashMap.put(arr[i],arr[i]*arr[i]);
		}
		System.out.println(hashMap);
	}
	public static void main(String args[]) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the key index:");
		int input=scanner.nextInt();
		System.out.println("enter the key values:");
		int arr[]=new int[input];
		for(int i=0;i<input;i++) {
			arr[i]=scanner.nextInt();
		}
		Excercise3 excercise3=new Excercise3();
		excercise3.getSquares(arr);
	}
	
}
