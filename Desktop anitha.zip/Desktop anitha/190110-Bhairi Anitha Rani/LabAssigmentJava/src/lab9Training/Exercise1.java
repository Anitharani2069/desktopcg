package lab9Training;
import java.util.*;
public class Exercise1 {
	List<Integer> getValues(HashMap<Integer,String> hash) 
	{
		Set<Integer> s=hash.keySet();
		List<Integer> list=new ArrayList<Integer>(s);
		Collections.sort(list);
		return list;
	}
	public static void main(String args[]) {
		HashMap<Integer,String> hashMap=new HashMap<Integer,String>();  //hashMap Creation
		hashMap.put(1,"hello");        //adding values to list
		hashMap.put(15,"anitha");
		hashMap.put(11, "Happy");
		Exercise1 excercise=new Exercise1();
		List<Integer> list1=excercise.getValues(hashMap);
		System.out.println(list1);
		System.out.println(hashMap);
	}
}
