package lab9Training;
import java.util.*;

import java.util.Scanner;
class HelperClass 
{

	 public HashMap countCharacter(char[] arr) 
	 {
		 {
		HashMap<Character,Integer> hashMap=new HashMap<Character,Integer>();
		for(char character:arr)
		{
		if(hashMap.containsKey(character))	{
			hashMap.put(character,hashMap.get(character)+1);
		}
		else {
			hashMap.put(character,1);
			}
		}
		return hashMap;
		}
	 }
}
	 public class Excercise2 
	 {
	public static void main(String args[])
	{
		HelperClass helperclass=new HelperClass();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the characters:");
		String string=scanner.next();
		char[] character=string.toCharArray();
		HashMap hashMap1=helperclass.countCharacter(character);
		Excercise2 excercise2=new Excercise2();
		System.out.println(hashMap1);
	}
}