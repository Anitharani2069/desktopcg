package lab10Training;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;

import java.io.FileWriter;
import java.util.*;
public  class Excercise1 implements Runnable{
	public void run() {
		FileReader f=null;
		FileWriter f1=null;
		BufferedReader bufferreader=null;
		BufferedWriter bufferwriter=null;
		String line="";
		try {
			f=new FileReader("source.txt");
			f1=new FileWriter("source.txt,true ");
			bufferreader= new BufferedReader(f);
			bufferwriter=new BufferedWriter(f1);
			line=bufferreader.readLine();
			while(line!=null); {
				System.out.println(line);
				bufferwriter.write(line.toString());
				bufferwriter.flush();
				line=bufferreader.readLine();
			}
		f1.close();
	}
	catch (Exception exception) {
		System.out.println(exception);
	}
	}
	public static void main(String args[]) {
		Excercise1 obj=new Excercise1();
		Thread thread=new Thread(obj);
		thread.start();
	}
}
	
 