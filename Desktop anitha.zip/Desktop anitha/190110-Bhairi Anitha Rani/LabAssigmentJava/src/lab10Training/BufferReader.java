package lab10Training;

public interface BufferReader {

}
