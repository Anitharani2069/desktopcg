package lab10Training;

public interface BufferWriter {

}
