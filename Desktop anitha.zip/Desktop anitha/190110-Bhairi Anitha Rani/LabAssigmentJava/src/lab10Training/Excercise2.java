package lab10Training;

public class Excercise2 implements Runnable{
	int count=0;
	public void run() {
		while(true) {
			System.out.println("Timer ="+count+ " seconds");
			try {
				Thread.sleep(1000);
				count++;
				if(count==1) {
					System.out.println("\nTimer Reset\n");
					count=0;
				}
			}
			catch (InterruptedException exception) {
				exception.printStackTrace();
			} 
		}
	}
	public static void main(String args[]) {
		Excercise2 excercise2=new Excercise2();
		Thread thread=new Thread(excercise2);
		thread.start();
	}

}
