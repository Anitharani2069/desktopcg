package com.cg.eis.exception;
import java.util.Scanner;
class EmployeeException extends Exception
{
public EmployeeException(String str)
	{
		System.out.println(str);
	}
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Salary:");
		int Salary =sc.nextInt();
		try{
			if (Salary<3000) {
			throw new EmployeeException("please give salary more than 3000");
			}
			else 
				System.out.println("Your salry is:"+Salary);
			}
		catch(EmployeeException e) {
			System.out.println("Employee Exception occured"+e);
		}
	}
}
	