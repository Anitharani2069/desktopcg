package com.cg.eis.exception;
import java.util.Scanner;
class InvalidAgeException extends Exception
{
public InvalidAgeException(String str)
	{
		System.out.println(str);
	}
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age:");
		int age =sc.nextInt();
		try{
			if (age<15) {
			throw new InvalidAgeException("Invalid age");
			}
			else 
				System.out.println("Valid age");
			}
		catch(InvalidAgeException e) {
			System.out.println("Invalid age Exception occured"+e);
		}
	}
}
	