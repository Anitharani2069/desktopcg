package lab2Training;

 abstract class Item {
	private String title;
	private int copies;
	private int id;
	public Item(int id, String title, int copies) {
		this.id = id;
		this.title = title;
		this.copies = copies;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCopies() {
		return copies;
	}
	public void setCopies(int copies) {
		this.copies = copies;
	}
	@Override
	public String toString() {
		return "Item [id=" + id + ", title=" + title + ", copies=" + copies + "]";
	}
	public boolean equals(Object obj) 
	{
		if(this==obj)
		{
		return true;
		}
		if(obj==null) 
		{	
			return false;
			}
		if(getClass()!=obj.getClass())
			{return false;}
		Item other=(Item) obj;
		if(id!=other.copies)
		{return false;}
		if(title==null) 
			if(other.title!=null)
			return false;
		
	else if (!title.equals(other.title))
		return false;
	return true;
 }
 public void checkIn()
 {
	 
 }
 public void checkOut() 
 {
	 
 }
 public void addItem() 
 {
	 
 }
 }
 abstract class WrittenItem extends Item {
	 private String authorName;
	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public WrittenItem(int id,String title,int copies, String authorName){
		super(id,title,copies);
	}
	}
 abstract class Book extends WrittenItem {
	 public Book(int id,String title,int copies,String authorName) {
		 super(id,title,copies,authorName);
	 }
 }
 abstract class JournalPaper extends WrittenItem {
	 private int year;
	 public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public JournalPaper(int id, String title, int copies, String authorName,int year) {
		super(id, title, copies, authorName);
	
	}

 }
abstract class MediaItem extends Item{
	private int number;
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public MediaItem(int id, String title, int copies,int year) {
		super(id, title, copies);
	}
} 
abstract class Video extends MediaItem{
	private String director;
	private String genre;
	private int year;
	public Video(int id, String title, int copies, int year,int number,String genre) {
		super(id, title, copies, year);	
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
abstract class CD extends MediaItem{
	private String artist;
	private String genre;
	public CD(int id, String title, int copies, int number,String artists,String genre) {
		super(id, title, copies, number);
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
}
 
 
 
 
