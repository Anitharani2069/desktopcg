package com.cg.eis.service;

	import com.cg.eis.bean.Employee;
	public class Service implements ServiceInterface
	{
	    public void Employ(Employee employee)
	    {
	       
	        if(employee.getSalary()>5000 && employee.getSalary()<20000)
	        {
	        employee.setDesignation("System Associate");
	        employee.setInsuranceScheme("Scheme C");
	        }
	        else
	            if(employee.getSalary()>20000 && employee.getSalary()<40000)
	            {
	                employee.setDesignation("programmer");
	                employee.setInsuranceScheme("Scheme D");
	                }
	            else
	                if(employee.getSalary()>=40000)
	                {
	                    employee.setDesignation("Manager");
	                    employee.setInsuranceScheme("A");
	                }
	                else
	                    if(employee.getSalary()<5000)
	                    {
	                        employee.setDesignation("clerk");
	                        employee.setInsuranceScheme(" No Scheme ");   
	                    }
	       
	}
	}
