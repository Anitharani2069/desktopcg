package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;
public class MainUi {
	public static void main(String args[]) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		int Id=scanner.nextInt();
		System.out.println("Enter Employee Name:");
		String Name=scanner.next();
		System.out.println("Enter Employee Salary:");
		double Salary=scanner.nextDouble();
		System.out.println("Enter Employee Designation:");
		String Designation=scanner.next();
		System.out.println("Enter Employee InsuranceScheme:");
		String InsuranceScheme=scanner.next();
		Employee employee1=new Employee(Id,Name,Salary,Designation,InsuranceScheme);
		System.out.println(employee1);
	}

}
