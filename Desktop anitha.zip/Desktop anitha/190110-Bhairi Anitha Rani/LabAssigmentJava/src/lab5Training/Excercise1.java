package lab5Training;
import java.util.Scanner;
public class Excercise1 
{
	public static void main(String args[]) {
		String color;
		Scanner scanner=new Scanner(System.in);
		color=scanner.next();
		switch (color)
		{
		case "red" :
			System.out.println("stop");
			break;
		case "yellow" :
			System.out.println("ready");
			break;
		case "green" :
			System.out.println("go");
			break;
		default:
			System.out.println("given instructon is wrong");
			break;
		}
	}
}
