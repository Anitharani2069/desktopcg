package lab11Training;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;



public class FileProgram {
public static void main(String args[]) {
	BufferedReader bufferReader=new BufferedReader(new InputStreamReader(System.in));
	try {
		System.out.println("Enter Source file path");
		File source_file=new File(bufferReader.readLine());
		System.out.println("Enter target file path ");
		File target_file=new File(bufferReader.readLine());
		Executor executor=Executors.newSingleThreadExecutor();
		FileReader reader=new FileReader(source_file);
		FileWriter writer=new FileWriter(target_file);
		executor.execute(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				int element;
				int count=0;
				try {
					while((element =reader.read())!=-1) {
						writer.write(element);
						count++;
						if(count==10)
							count =0;
						System.out.println("10 characters are copied");
						sleep(10000);
				
					}
				System.out.println("File copied sucessfully");
			}
			catch (IOException exception) {
				System.out.println("Error in reading and writing file");
			} 
			finally {
				try {
					reader.close();
					writer.close();
				} 
				catch(IOException exception) {
					System.out.println("Error in reading and writing file");
				}
				catch (NullPointerException exception) {
					System.out.println("One of the given file doesnot exist");
				}
			}
			
		}

			private void sleep(int i) {
				// TODO Auto-generated method stub
				
			}
	});
	}
catch (IOException e) {
	System.out.println("Wrong input given");
	}
}
}
