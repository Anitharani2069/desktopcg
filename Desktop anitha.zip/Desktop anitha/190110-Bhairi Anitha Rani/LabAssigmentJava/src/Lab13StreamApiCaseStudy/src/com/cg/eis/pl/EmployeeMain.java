package com.cg.eis.pl;

import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService es=new EmployeeService();
		List<Employee> elist=EmployeeRepository.getEmployees();
		
		System.out.println("Sum of the salary\t:\t"+es.getSumOfSalary(elist));
		System.out.println("Employee without dept\t:\t");
		List<Employee> el2=es.getEmployeeWithoutDept(elist);
		for(Employee e:el2)
			System.out.println(e);
		System.out.println("employee without manager\t:\t");
		List<Employee> el3=es.didnotHaveManager(elist);
		for(Employee e:el3)
		System.out.println(e);
		
		System.out.println("List sorted by First Name");
		List<Employee> el5=es.sortName(elist);
		for(Employee e:el5)
			System.out.println(e);
		
		System.out.println("List sorted by Employee id");
		List<Employee> el6=es.sortEmpId(elist);
		for(Employee e:el6)
			System.out.println(e);
		
		System.out.println("List sorted by Department id");
		List<Employee> el7=es.sortDeptId(elist);
		for(Employee e:el7)
			System.out.println(e);

	}

}
