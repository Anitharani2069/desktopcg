package lab3Training;
import java.util.Arrays;
import java.util.Scanner;
public class Excercise2 {
    public String[] getSorted(String arr[])
    {
        int length=arr.length;
        Arrays.sort(arr);
        if(length%2==0)
        {
            for(int i=0;i<length/2;i++)
            {
                arr[i]=arr[i].toUpperCase();
            }
            for(int i=(length/2)+1;i<length;i++)
            {
                arr[i]=arr[i].toLowerCase();
            }
        }
        else
        {
            for(int i=0;i<length/2;i++)
            {
                arr[i]=arr[i].toUpperCase();
            }
            for(int i=(length/2)+1;i<length;i++)
            {
                arr[i]=arr[i].toLowerCase();
            }
        }
        for(int i=0;i<length;i++)
        {
            System.out.println(arr[i]);
        }
        return arr;
    }
    public static void main(String args[])
    {
        Scanner scanner=new Scanner(System.in);
        int number=scanner.nextInt();
        String str[]=new String[number];
        for(int i=0;i<number;i++)
        {
            str[i]=scanner.next();
        }
        Excercise2 excerciseObj=new Excercise2();
        excerciseObj.getSorted(str);
    }
}