package lab3Training;
import java.util.Scanner;
public class Excercise1 {
	public int getSecondSmallest(int num[]) {
		int number=num.length;
		int arr[]=new int[number];
		int temp=0;
	        for(int i = 0; i < number; i++)
	        	for(int j=i+1;j<number;j++)
	        {
	            if(num[i]>num[j])
	            {
	               temp=num[i];
	               num[i]=num[j];
	               num[j]=temp;
	            }
	        }
			return num[1];
		}
		
	
		public static void main(String args[]) 
		{
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter the no of array integers:");
			int input=scanner.nextInt();
			System.out.println("Enter the array Integers:");
			int arr[]=new int[input];
			for(int i=0;i<input;i++)
			{
				arr[i]=scanner.nextInt();
			}
			Excercise1 excercise=new Excercise1();
			System.out.println("The second smallest Integer:");
			System.out.println(excercise.getSecondSmallest(arr));	
	}
}

		
