package lab13Training;
interface Power {
	public int caluclate(int num1, int num2);
}
public class Excercise1 {
public static void main(String args[]) {
	Power power=(num1,num2)->{
		int result=1;
		for(int i=1;i<=num2;i++) 
			result=result*num1;
		return result;
	};
	int result=power.caluclate(3,4);
	System.out.println(result);
}
}
