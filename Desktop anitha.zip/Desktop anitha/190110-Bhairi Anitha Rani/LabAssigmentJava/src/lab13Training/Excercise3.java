package lab13Training;
import java.util.Scanner;
import java.util.Comparator;
interface lambda1{
	public boolean print(String name,String password);
}
public class Excercise3 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		String name1=scan.next();
		System.out.println("Entered name "+name1);
		String password1=scan.next();
		System.out.println("Entered password "+password1);
		lambda1 lambda=(name,pass)->{if(name.equals(name1)&&pass.equals(password1))
			return true;
		else
			return false;
		};
		boolean output=lambda.print("anitha", "414");
		System.out.println(output);
	}
}
