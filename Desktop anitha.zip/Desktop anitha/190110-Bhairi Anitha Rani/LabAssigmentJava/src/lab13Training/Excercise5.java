package lab13Training;
import java.util.function.Function;
public class Excercise5 {
public static void main(String args[]) {
	Excercise5 excercise5=new Excercise5() ;
	Function<Integer,Long>fun=excercise5::fact;
	long result=fun.apply(5);
	System.out.println(result);
}
public long fact(int number) {
	long factres=1;
	for(int i=1;i<=number;i++){
		factres=factres*i;
		}
	return factres;
	
}
}
