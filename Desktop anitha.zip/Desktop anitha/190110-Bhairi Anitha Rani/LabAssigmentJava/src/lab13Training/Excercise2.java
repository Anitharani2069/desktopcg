package lab13Training;
import java.util.*;

import java.util.Scanner;
interface lambda {
	public String print(String string);
}
public class Excercise2 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		String string1=scan.next();
		lambda lam=(string)-> {
			StringBuilder builder=new StringBuilder();
			for(int i=0;i<string1.length();i++) {
				builder=builder.append(string1.charAt(i)).append(" ");
			}
			return builder.toString();
		};
		String string2=lam.print(string1);
		System.out.println(" " +string2);
	}
}
