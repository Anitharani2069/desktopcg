package lab1Training;
import java.lang.Math;
import java.util.Scanner;
public class Excercise4 {
	public boolean checkNumber(int number)
	{
		int i=1,num1 = 0;
		while(i<10)
		{
			num1=(int) Math.pow(2,i);
			if(num1==number)
			{
				return true;
			}
			i++;
		}
		return false;
	}
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	int output=scanner.nextInt();
	Excercise4 excercise=new Excercise4();
	System.out.println(excercise.checkNumber(output));
}
}
