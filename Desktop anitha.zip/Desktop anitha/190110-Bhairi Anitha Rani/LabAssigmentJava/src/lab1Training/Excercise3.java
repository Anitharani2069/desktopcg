package lab1Training;

import java.util.Scanner;

public class Excercise3 {
	public boolean checkNumber(int number)
	{
		while(number>0)
		{
			int value1=number%10;
			number=number/10;
			int value2=number%10;
			if(value1<value2)
			{
				return false;
			}
		}
		return true;
	}
	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		int output=scanner.nextInt();
		Excercise3 excercise=new Excercise3();
		System.out.println(excercise.checkNumber(output));
	}

}
